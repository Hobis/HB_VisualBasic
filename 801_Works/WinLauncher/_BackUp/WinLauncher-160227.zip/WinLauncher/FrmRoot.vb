﻿Imports System
Imports System.Drawing
Imports System.Collections.Generic
Imports System.Collections.Specialized
Imports System.IO
Imports System.Web
Imports System.Windows.Forms


' ##
Public NotInheritable Class FrmRoot

#Region ">>>>>>>> MainInit's"
    ' :: 생성자
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        p_InitOnce()
    End Sub
    ' - 루트윈도우 참조
    Private Shared _FramRoot As FrmRoot = Nothing
    ' - 서브윈도우 참조
    Private Shared _FrmSub As FrmRoot = Nothing

    ' ::
    Private Sub p_InitOnce()
        Me.Text = "Window Launcher Ver 1.02 >> EBS Touch-Mong"
        '
        _WebBrowser1.ObjectForScripting = Me
        _WebBrowser1.IsWebBrowserContextMenuEnabled = False
        _WebBrowser1.AllowWebBrowserDrop = False
        _WebBrowser1.ScrollBarsEnabled = False
        _WebBrowser1.ScriptErrorsSuppressed = True
        _WebBrowser1.WebBrowserShortcutsEnabled = False
        AddHandler _WebBrowser1.PreviewKeyDown, AddressOf Me.p_WebBrowser1_PreviewKeyDown
        '
        If _FramRoot Is Nothing Then
            _FramRoot = Me
            _FramRoot.MaximizeBox = False
            _FrmSub = New FrmRoot()
            Dim t_src As String = Path.Combine(Application.StartupPath, "FlaRoot.swf")
            _WebBrowser1.Navigate(t_src)
        End If
    End Sub

    ' ::
    Private Sub p_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '
    End Sub

    ' ::
    Private Sub p_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        'If Me.Modal Then
        '    p_SetFullScreen(True)
        'End If
    End Sub

    ' ::
    Private Sub p_WebBrowser1_PreviewKeyDown( _
                    ByVal sender As Object, _
                    ByVal pkdea As PreviewKeyDownEventArgs)
        '
        Select Case pkdea.KeyCode
            Case Keys.Escape
                p_SetFullScreen(False)

            Case Keys.F5
                _WebBrowser1.Refresh()

            Case Keys.F11
                p_FullScreen_Toggle()
        End Select
    End Sub

    ' ::
    Private Sub p_Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'p_SubClose()
        p_SubOpen("naver.com")
    End Sub

    ' ::
    Private Sub p_SubClose()
        'If _FrmSub Is Nothing Then Exit Sub
        ''
        'MessageBox.Show(_FrmSub._WebBrowser1.ToString())
        '_FrmSub._WebBrowser1.Navigate("about:Blank")
        '_FrmSub.
    End Sub

    ' ::
    Private Sub p_SubOpen(url As String)
        If _FrmSub Is Nothing Then Exit Sub
        '
        Me.Hide()
        p_SetFullScreen(False)
        _FrmSub._WebBrowser1.Navigate(url)
        _FrmSub.ShowDialog(Me)
        Me.Show()
    End Sub

#End Region



#Region ">>>>>>>> WindowFullScreen"

    Private Const _WM_SYSCOMMAND As Integer = &H112
    Private Const _SC_MAXIMIZE As Integer = &HF030
    Protected Overrides Sub WndProc(ByRef m As Message)
        If (m.Msg.Equals(_WM_SYSCOMMAND)) Then
            If (m.WParam.ToInt32().Equals(_SC_MAXIMIZE)) Then
                Me.p_FullScreen_Toggle()
                Exit Sub
            End If
        End If
        '
        MyBase.WndProc(m)
    End Sub

    ' ::
    Private Sub p_FullScreen_Toggle()
        If (Me.TopMost) Then
            Me.p_SetFullScreen(False)
        Else
            Me.p_SetFullScreen(True)
        End If
    End Sub

    ' -
    Private _tempSize As Size = Size.Empty
    ' ::
    Private Sub p_SetFullScreen(ByVal b As Boolean)
        If (b) Then
            If (Not Me.TopMost) Then
                Me.TopMost = True
                Me._tempSize = Me.Size
                Me.FormBorderStyle = FormBorderStyle.None
                Me.WindowState = FormWindowState.Maximized
                'Me.WebBrowser1.Focus()
            End If
        Else
            If (Me.TopMost) Then
                Me.TopMost = False
                Me.WindowState = FormWindowState.Normal
                Me.FormBorderStyle = FormBorderStyle.Sizable
                Me.Size = Me._tempSize
                Me._tempSize = Size.Empty
            End If
        End If
    End Sub

#End Region

End Class



#Region ">>>>>>>> MUtils"
' #
Public Module MUtils
    Private Const _Caption As String = "# 알림"

    Public Sub fMsgBox(ByVal str As String)
        MessageBox.Show(str, _Caption)
    End Sub

    ' :: pObj -> qStr
    Public Function fConvert_qStr(ByVal nvc As NameValueCollection) As String
        Dim t_rv As String = Nothing

        Dim t_list As List(Of String) = New List(Of String)()
        Dim t_name As String

        For Each t_name In nvc
            Dim t_value As String = nvc(t_name)
            t_value = HttpUtility.UrlEncode(t_value)
            Dim t_str = String.Concat(t_name, "=", t_value)
            t_list.Add(t_str)
        Next

        If (t_list.Count > 0) Then
            t_rv = String.Join("&", t_list.ToArray())
        End If

        t_list.Clear()

        Return t_rv
    End Function

    ' :: qStr -> pObj
    Public Function fConvert_pObj(ByVal qStr As String) As NameValueCollection
        Dim t_nvc As NameValueCollection = HttpUtility.ParseQueryString(qStr)

        If (t_nvc.Count > 0) Then
            Return t_nvc
        End If

        Return Nothing
    End Function
End Module
#End Region


#Region ">>>>>>>> Win32 Handling"
Public Module MWin32

End Module
#End Region
