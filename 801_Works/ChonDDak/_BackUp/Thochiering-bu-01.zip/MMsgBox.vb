﻿Imports System
Imports System.Drawing
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
'Imports System.Threading


Public Module MMsgBox

#Region "Initalize"

    Private Const _Kernel32dll As String = "kernel32.dll"
    Private Const _User32dll As String = "user32.dll"


    Private Const _WH_CALLWNDPROCRET As Integer = 12

    Private Const _HCBT_ACTIVATE As Integer = 5

    Private Delegate Function _HookProc(ByVal nCode As Integer, _
                                        ByVal wParam As IntPtr, _
                                        ByVal lParam As IntPtr) As Integer


    ' ::
    <DllImportAttribute(_Kernel32dll, _
        EntryPoint:="GetCurrentThreadId", _
        CharSet:=CharSet.Auto,
        CallingConvention:=CallingConvention.StdCall, _
        SetLastError:=True)> _
    Private Function p_GetCurrentThreadId() As Integer
    End Function

    ' ::
    <DllImportAttribute(_User32dll, _
        EntryPoint:="SetWindowsHookEx", _
        CharSet:=CharSet.Auto,
        CallingConvention:=CallingConvention.StdCall, _
        SetLastError:=True)> _
    Private Function p_SetWindowsHookEx(ByVal idHook As Integer, _
                                        ByVal lpfn As _HookProc, _
                                        ByVal hMod As IntPtr, _
                                        ByVal dwThreadId As UInteger) As IntPtr
    End Function

    ' ::
    <DllImportAttribute(_User32dll, _
        EntryPoint:="UnhookWindowsHookEx", _
        CharSet:=CharSet.Auto,
        CallingConvention:=CallingConvention.StdCall, _
        SetLastError:=True)> _
    Private Function p_UnhookWindowsHookEx(ByVal hHook As IntPtr) As Boolean
    End Function

    ' ::
    <DllImportAttribute(_User32dll, _
        EntryPoint:="CallNextHookEx", _
        CharSet:=CharSet.Auto,
        CallingConvention:=CallingConvention.StdCall, _
        SetLastError:=True)> _
    Private Function p_CallNextHookEx(ByVal hHook As IntPtr, _
                                      ByVal nCode As Integer, _
                                      ByVal wParam As IntPtr, _
                                      ByVal lParam As IntPtr) As IntPtr
    End Function

    ' ::
    <DllImportAttribute(_User32dll, _
        EntryPoint:="GetWindowRect", _
        CharSet:=CharSet.Auto,
        CallingConvention:=CallingConvention.StdCall, _
        SetLastError:=True)> _
    Private Function p_GetWindowRect(ByVal hWnd As IntPtr, _
                                     ByRef lpRect As Rectangle) As Boolean
    End Function

    ' ::
    '<DllImportAttribute(_User32dll, _
    '    EntryPoint:="MoveWindow", _
    '    CharSet:=CharSet.Auto,
    '    CallingConvention:=CallingConvention.StdCall, _
    '    SetLastError:=True)> _
    'Private Function p_MoveWindow(ByVal hWnd As IntPtr, _
    '                              ByVal x As Integer, ByVal y As Integer, _
    '                              ByVal w As Integer, ByVal h As Integer, _
    '                              ByVal redraw As Boolean) As Boolean
    'End Function

    ' ::
    <DllImportAttribute(_User32dll, _
        EntryPoint:="SetWindowPos", _
        CharSet:=CharSet.Auto,
        CallingConvention:=CallingConvention.StdCall, _
        SetLastError:=True)> _
    Private Function p_SetWindowPos(ByVal hWnd As IntPtr, _
                                  ByVal hWndInsertAfter As IntPtr, _
                                  ByVal x As Integer, ByVal y As Integer, _
                                  ByVal cx As Integer, ByVal cy As Integer,
                                  ByVal uFlags As UInteger) As Boolean
    End Function


    <StructLayout(LayoutKind.Sequential)> _
    Private Structure _CWPRETSTRUCT
        Public lResult As IntPtr
        Public lParam As IntPtr
        Public wParam As IntPtr
        Public message As UInteger
        Public hwnd As IntPtr
    End Structure

#End Region



    Private _Owner As IWin32Window = Nothing
    Private _HookProcDelegate As _HookProc = Nothing
    Private _hHook As IntPtr = IntPtr.Zero

    ' ::
    Public Function Show_Fbd( _
                        ByVal fbd As FolderBrowserDialog, _
                        ByVal owner As IWin32Window) As DialogResult
        '_Owner = owner
        'p_Ready()
        '
        MessageBox.Show(fbd.Container Is Nothing)
        'fbd.

        Return fbd.ShowDialog(_Owner)
    End Function

    ' ::
    Public Function Show(ByVal owner As IWin32Window, _
                         ByVal msg As String, _
                         ByVal caption As String) As DialogResult
        '_Owner = owner
        'p_Ready()
        '
        Return MessageBox.Show(_Owner, msg, caption)
    End Function

    ' ::
    Private Sub p_Ready()
        If (_HookProcDelegate Is Nothing) Then
            _HookProcDelegate = AddressOf p_HookProc
        End If

        If (Not _Owner Is Nothing) Then
            _hHook = p_SetWindowsHookEx(_WH_CALLWNDPROCRET, _HookProcDelegate, IntPtr.Zero, p_GetCurrentThreadId())
        End If
    End Sub

    ' ::
    Private Function p_HookProc(ByVal nCode As Integer, _
                                ByVal wParam As IntPtr, _
                                ByVal lParam As IntPtr) As Integer
        If (nCode < 0) Then
            Return p_CallNextHookEx(_hHook, nCode, wParam, lParam)
        End If

        '
        Dim t_msg As _CWPRETSTRUCT = _
            CType(Marshal.PtrToStructure(lParam, GetType(_CWPRETSTRUCT)), _CWPRETSTRUCT)
        Dim t_hh As IntPtr = _hHook

        If (t_msg.message = _HCBT_ACTIVATE) Then
            Try
                p_CenterWindow(t_msg.hwnd)
            Finally
                p_UnhookWindowsHookEx(_hHook)
                _hHook = IntPtr.Zero
            End Try
        End If

        Return p_CallNextHookEx(t_hh, nCode, wParam, lParam)
    End Function

    ' ::
    Private Sub p_CenterWindow(ByVal hChildWnd As IntPtr)
        'Dim t_recChild As New Rectangle(0, 0, 0, 0)
        'Dim t_success As Boolean = p_GetWindowRect(hChildWnd, t_recChild)

        'Dim t_width As Integer = t_recChild.Width - t_recChild.X
        'Dim t_height As Integer = t_recChild.Height - t_recChild.Y


        'Dim t_recParent As New Rectangle(0, 0, 0, 0)
        't_success = p_GetWindowRect(_Owner.Handle, t_recParent)
        ''MessageBox.Show("t_recParent.Left: " & t_recParent.Left & ", t_recParent.Top: " & t_recParent.Top & ", t_recParent.Right: " & t_recParent.Right)

        'Dim t_ptcenter As New Point(0, 0)
        't_ptcenter.X = t_recparent.X + ((t_recparent.Width - t_recparent.X) / 2)
        't_ptcenter.Y = t_recparent.Y + ((t_recparent.Height - t_recparent.Y) / 2)

        'Dim t_ptstart As New Point(0, 0)
        't_ptstart.X = (t_ptcenter.X - (t_width / 2))
        't_ptstart.Y = (t_ptcenter.Y - (t_height / 2))
        ''t_ptstart.x = if((t_ptstart.x < 0), 0, t_ptstart.x)
        ''t_ptstart.y = if((t_ptstart.y < 0), 0, t_ptstart.y)

        'Dim t_result As Integer = p_movewindow(hChildWnd, t_ptstart.X, t_ptstart.Y, t_width, t_height, False)



        Dim t_recChild As New Rectangle(0, 0, 0, 0)
        Dim t_success As Boolean = p_GetWindowRect(hChildWnd, t_recChild)
        Dim t_cxChild As Integer = t_recChild.Right - t_recChild.Left
        Dim t_cyChild As Integer = t_recChild.Bottom - t_recChild.Top

        Dim t_hParent As IntPtr = _Owner.Handle
        Dim t_recParent As New Rectangle(0, 0, 0, 0)
        t_success = p_GetWindowRect(t_hParent, t_recParent)
        MessageBox.Show(t_recParent.ToString())
        Dim t_cxParent As Integer = t_recParent.Right - t_recParent.Left
        Dim t_cyParent As Integer = t_recParent.Bottom - t_recParent.Top

        Dim t_x As Integer = t_recParent.Left + ((t_cxParent - t_cxChild) / 2)
        Dim t_y As Integer = t_recParent.Top + ((t_cyParent - t_cyChild) / 2)
        Dim t_uflags As UInteger = &H15 ' swp_nosize | swp_nozorder | swp_noactivate;
        p_SetWindowPos(hChildWnd, IntPtr.Zero, 0, t_y, 0, 0, t_uflags)


        'Dim t_uFlags As UInteger = &H15 ' SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE;
        'p_SetWindowPos(hChildWnd, IntPtr.Zero, 100, 0, 0, 0, t_uFlags)
        ''MessageBox.Show(hChildWnd.ToString)
    End Sub

End Module
